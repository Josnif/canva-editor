# Scenify SDK

_Warning: this project is not production ready, API might change without notice._

Scenify SDK is available on npm as @scenify/sdk. This single package contains all components required to build a design editor.

```sh
# using yarn
yarn add @scenify/sdk

# using npm
npm install @scenify/sdk
```

**View full documentation and examples on [Scenify SDK Docs](https://docs.scenify.dev)**

## Join us on Discord

<p>
    <a href="https://discord.gg/HqyXEhkXNZ">
        <img src="https://discordapp.com/api/guilds/898955692491309126/widget.png?style=banner2" alt="Discord Banner 2"/>
    </a>
</p>
<!-- 177d8013c568c4d17f43a4909fdb32469a86f20b -->
